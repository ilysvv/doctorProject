<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans text-gray-900 antialiased" style="margin: 0; padding: 0;">
<div class="w-full">
    <?php echo e($slot); ?>

</div>
</body>
</html>
<?php /**PATH C:\Users\yousef\doctorProject\resources\views/layouts/guest.blade.php ENDPATH**/ ?>