<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('لوحة التحكم')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">

                <?php if(auth()->user()->role === 'doctor'): ?>
                    <!-- واجهة الدكتور -->
                    <h3 class="text-lg font-bold text-blue-500">مرحباً دكتور <?php echo e(auth()->user()->name); ?></h3>
                    <p class="mt-4 text-gray-600 dark:text-gray-400">هنا ستظهر قائمة الحجوزات المطلوبة منك لإدارتها.</p>
                    <a href="#" class="mt-4 inline-block bg-blue-600 text-white px-4 py-2 rounded">عرض حجوزات المرضى</a>

                <?php else: ?>
                    <!-- واجهة المريض -->
                    <h3 class="text-lg font-bold text-green-500">مرحباً بك يا <?php echo e(auth()->user()->name); ?></h3>
                    <p class="mt-4 text-gray-600 dark:text-gray-400">يمكنك البحث عن طبيب وحجز موعد جديد من هنا.</p>
                    <a href="<?php echo e(route('doctors.index')); ?>" class="mt-4 inline-block bg-green-600 text-white px-4 py-2 rounded">بحث عن دكتور</a>
                <?php endif; ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\yousef\doctorProject\resources\views/dashboard.blade.php ENDPATH**/ ?>